export interface CardDetails {
  number: string;
  expiry: string;
  cvv: string;
  cardholder: string;
}

export interface TerminalSimulation {
  status: 'approved' | 'declined';
  arqc: string;
  timestamp: string;
}

export interface Log {
  type: string;
  details: Record<string, unknown>;
  timestamp: string;
}