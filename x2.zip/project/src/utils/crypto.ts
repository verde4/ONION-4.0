import CryptoJS from 'crypto-js';

const TERMINAL_KEY = 'secure_terminal_key_2024';
const ENCRYPTION_KEY = 'card_encryption_key_2024';

export function generateARQC(cardData: string): string {
  const timestamp = Date.now().toString();
  const data = `${cardData}|${timestamp}`;
  return CryptoJS.SHA256(data).toString().substring(0, 16);
}

export function generateARPC(arqc: string): string {
  const timestamp = Date.now().toString();
  return CryptoJS.SHA256(arqc + TERMINAL_KEY + timestamp).toString().substring(0, 16);
}

export function encryptCardData(data: Record<string, unknown>): string {
  const jsonData = JSON.stringify(data);
  return CryptoJS.AES.encrypt(jsonData, ENCRYPTION_KEY).toString();
}

export function decryptCardData(encryptedData: string): string {
  const bytes = CryptoJS.AES.decrypt(encryptedData, ENCRYPTION_KEY);
  return bytes.toString(CryptoJS.enc.Utf8);
}