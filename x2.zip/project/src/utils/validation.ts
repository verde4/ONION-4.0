export function validateCardNumber(number: string): boolean {
  const cleanNumber = number.replace(/\s/g, '');
  const regex = /^[0-9]{16}$/;
  return regex.test(cleanNumber) && luhnCheck(cleanNumber);
}

function luhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i));
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

export function validateExpiry(expiry: string): boolean {
  const regex = /^(0[1-9]|1[0-2])\/([0-9]{2})$/;
  if (!regex.test(expiry)) return false;
  
  const [month, year] = expiry.split('/');
  const now = new Date();
  const expiryDate = new Date(2000 + parseInt(year), parseInt(month) - 1);
  
  return expiryDate > now;
}

export function validateCVV(cvv: string): boolean {
  return /^[0-9]{3}$/.test(cvv);
}

export function validateCardholder(name: string): boolean {
  return /^[A-Za-zÀ-ÖØ-öø-ÿ\s]{3,}$/.test(name);
}