import { useState } from 'react';
import { Log } from '../types/card';

export function useLogs() {
  const [logs, setLogs] = useState<Log[]>([]);

  const addLog = (type: string, details: Record<string, unknown>) => {
    const newLog: Log = {
      type,
      details,
      timestamp: new Date().toISOString()
    };
    setLogs(prev => [...prev, newLog]);
  };

  const exportLogs = () => {
    const blob = new Blob([JSON.stringify(logs, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'card-simulator-logs.json';
    a.click();
    URL.revokeObjectURL(url);
    addLog('Exportação de Logs', { status: 'success' });
  };

  return {
    logs,
    addLog,
    exportLogs
  };
}