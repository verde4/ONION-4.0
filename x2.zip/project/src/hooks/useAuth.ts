import { useState } from 'react';
import { LoginCredentials, AuthState } from '../types/auth';

const VALID_CREDENTIALS = {
  username: 'onion',
  password: 'Verde_420'
};

export function useAuth() {
  const [auth, setAuth] = useState<AuthState>({
    isLoggedIn: false,
    username: null
  });

  const login = (credentials: LoginCredentials): boolean => {
    if (
      credentials.username === VALID_CREDENTIALS.username &&
      credentials.password === VALID_CREDENTIALS.password
    ) {
      setAuth({
        isLoggedIn: true,
        username: credentials.username
      });
      return true;
    }
    return false;
  };

  const logout = () => {
    setAuth({
      isLoggedIn: false,
      username: null
    });
  };

  return {
    isLoggedIn: auth.isLoggedIn,
    username: auth.username,
    login,
    logout
  };
}