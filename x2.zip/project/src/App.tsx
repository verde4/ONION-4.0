import { useState, useCallback } from 'react';
import { LoginForm } from './components/LoginForm';
import { CardForm } from './components/CardForm';
import { CardPreview } from './components/CardPreview';
import { TerminalSimulator } from './components/TerminalSimulator';
import { LogViewer } from './components/LogViewer';
import { KeyboardShortcuts } from './components/KeyboardShortcuts';
import { useAuth } from './hooks/useAuth';
import { useLogs } from './hooks/useLogs';
import { CardDetails, TerminalSimulation } from './types/card';

function App() {
  const { isLoggedIn, login, logout } = useAuth();
  const { logs, addLog, exportLogs } = useLogs();
  const [currentCard, setCurrentCard] = useState<CardDetails | null>(null);
  const [showSecretPanel, setShowSecretPanel] = useState(false);

  const handleLogin = (credentials: { username: string; password: string }) => {
    const success = login(credentials);
    if (success) {
      addLog('Login', { status: 'success' });
    }
    return success;
  };

  const handleCardSubmit = (cardDetails: CardDetails) => {
    setCurrentCard(cardDetails);
    addLog('Simulação de Cartão', {
      ...cardDetails,
      number: cardDetails.number.replace(/\d(?=\d{4})/g, '*')
    });
  };

  const handleTerminalSimulation = (result: TerminalSimulation) => {
    addLog('Simulação de Terminal', {
      status: result.status,
      arqc: result.arqc,
      timestamp: result.timestamp
    });
  };

  const handleCtrlZero = useCallback(() => {
    setShowSecretPanel(prev => !prev);
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <KeyboardShortcuts onCtrlZero={handleCtrlZero} />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-center mb-8">
          Simulação de Segurança - Cartões
        </h1>

        {!isLoggedIn ? (
          <LoginForm onLogin={handleLogin} />
        ) : (
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-8">
                <div className="bg-gray-800 p-8 rounded-lg shadow-lg">
                  <h2 className="text-2xl font-bold mb-6">
                    Painel de Simulação
                  </h2>
                  <CardForm onSubmit={handleCardSubmit} />
                </div>

                {currentCard && (
                  <TerminalSimulator
                    cardDetails={currentCard}
                    onSimulationComplete={handleTerminalSimulation}
                  />
                )}
              </div>

              <div className="space-y-8">
                {currentCard && <CardPreview card={currentCard} />}
                
                {logs.length > 0 && (
                  <LogViewer logs={logs} onExport={exportLogs} />
                )}
              </div>
            </div>

            {showSecretPanel && (
              <div className="mt-8 bg-gray-800 p-6 rounded-lg shadow-lg">
                <h3 className="text-xl font-bold mb-4">Painel de Controle</h3>
                <div className="space-y-4">
                  <button
                    onClick={logout}
                    className="bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700 transition-colors"
                  >
                    Encerrar Sessão
                  </button>
                  <button
                    onClick={exportLogs}
                    className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition-colors ml-4"
                  >
                    Exportar Todos os Logs
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}