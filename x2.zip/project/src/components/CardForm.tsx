import { useState } from 'react';
import { CreditCard, Calendar, Hash, User } from 'lucide-react';
import { CardDetails } from '../types/card';
import { validateCardNumber, validateExpiry, validateCVV, validateCardholder } from '../utils/validation';

interface CardFormProps {
  onSubmit: (cardDetails: CardDetails) => void;
}

export function CardForm({ onSubmit }: CardFormProps) {
  const [cardDetails, setCardDetails] = useState<CardDetails>({
    number: '',
    expiry: '',
    cvv: '',
    cardholder: ''
  });

  const [errors, setErrors] = useState<Partial<Record<keyof CardDetails, string>>>({});

  const validate = (): boolean => {
    const newErrors: Partial<Record<keyof CardDetails, string>> = {};

    if (!validateCardNumber(cardDetails.number)) {
      newErrors.number = 'Número de cartão inválido';
    }
    if (!validateExpiry(cardDetails.expiry)) {
      newErrors.expiry = 'Data de validade inválida';
    }
    if (!validateCVV(cardDetails.cvv)) {
      newErrors.cvv = 'CVV inválido';
    }
    if (!validateCardholder(cardDetails.cardholder)) {
      newErrors.cardholder = 'Nome do titular inválido';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(cardDetails);
    }
  };

  const handleChange = (field: keyof CardDetails) => (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value;
    
    // Format expiry date
    if (field === 'expiry') {
      value = value.replace(/\D/g, '').slice(0, 4);
      if (value.length >= 2) {
        value = value.slice(0, 2) + '/' + value.slice(2);
      }
    }
    
    // Format card number with spaces
    if (field === 'number') {
      value = value.replace(/\D/g, '').slice(0, 16);
      value = value.replace(/(\d{4})/g, '$1 ').trim();
    }
    
    // Format CVV
    if (field === 'cvv') {
      value = value.replace(/\D/g, '').slice(0, 3);
    }
    
    // Format cardholder name
    if (field === 'cardholder') {
      value = value.toUpperCase();
    }

    setCardDetails(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-gray-300 mb-2">
          <div className="flex items-center gap-2">
            <CreditCard size={18} />
            <span>Número do Cartão</span>
          </div>
        </label>
        <input
          type="text"
          value={cardDetails.number}
          onChange={handleChange('number')}
          className={`w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 ${
            errors.number ? 'border-red-500' : ''
          }`}
          placeholder="1234 5678 9012 3456"
        />
        {errors.number && <p className="text-red-500 text-sm mt-1">{errors.number}</p>}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-gray-300 mb-2">
            <div className="flex items-center gap-2">
              <Calendar size={18} />
              <span>Validade</span>
            </div>
          </label>
          <input
            type="text"
            value={cardDetails.expiry}
            onChange={handleChange('expiry')}
            className={`w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 ${
              errors.expiry ? 'border-red-500' : ''
            }`}
            placeholder="MM/AA"
          />
          {errors.expiry && <p className="text-red-500 text-sm mt-1">{errors.expiry}</p>}
        </div>

        <div>
          <label className="block text-gray-300 mb-2">
            <div className="flex items-center gap-2">
              <Hash size={18} />
              <span>CVV</span>
            </div>
          </label>
          <input
            type="text"
            value={cardDetails.cvv}
            onChange={handleChange('cvv')}
            className={`w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 ${
              errors.cvv ? 'border-red-500' : ''
            }`}
            placeholder="123"
          />
          {errors.cvv && <p className="text-red-500 text-sm mt-1">{errors.cvv}</p>}
        </div>
      </div>

      <div>
        <label className="block text-gray-300 mb-2">
          <div className="flex items-center gap-2">
            <User size={18} />
            <span>Nome do Titular</span>
          </div>
        </label>
        <input
          type="text"
          value={cardDetails.cardholder}
          onChange={handleChange('cardholder')}
          className={`w-full p-2 border rounded bg-gray-700 text-white border-gray-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 ${
            errors.cardholder ? 'border-red-500' : ''
          }`}
          placeholder="NOME COMO APARECE NO CARTÃO"
        />
        {errors.cardholder && <p className="text-red-500 text-sm mt-1">{errors.cardholder}</p>}
      </div>

      <button
        type="submit"
        className="w-full bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700 transition-colors"
      >
        Simular Cartão
      </button>
    </form>
  );
}