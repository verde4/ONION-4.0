import { Download, Clock } from 'lucide-react';
import { Log } from '../types/card';

interface LogViewerProps {
  logs: Log[];
  onExport: () => void;
}

export function LogViewer({ logs, onExport }: LogViewerProps) {
  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-2">
          <Clock size={20} className="text-blue-400" />
          <h2 className="text-xl font-bold text-white">Logs de Operações</h2>
        </div>
        
        <button
          onClick={onExport}
          className="flex items-center gap-2 bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition-colors"
        >
          <Download size={18} />
          Exportar Logs
        </button>
      </div>
      
      <div className="bg-gray-900 p-4 rounded-lg max-h-96 overflow-y-auto">
        {logs.map((log, index) => (
          <div key={index} className="mb-4 last:mb-0 border-b border-gray-700 pb-4 last:border-0">
            <div className="flex items-center gap-2 text-gray-400 text-sm mb-1">
              <Clock size={14} />
              <span>{new Date(log.timestamp).toLocaleString()}</span>
            </div>
            <span className="font-medium text-blue-400">{log.type}</span>
            <pre className="mt-2 text-sm text-gray-300 whitespace-pre-wrap">
              {JSON.stringify(log.details, null, 2)}
            </pre>
          </div>
        ))}
      </div>
    </div>
  );
}