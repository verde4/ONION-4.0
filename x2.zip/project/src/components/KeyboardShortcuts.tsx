import { useEffect } from 'react';

interface KeyboardShortcutsProps {
  onCtrlZero: () => void;
}

export function KeyboardShortcuts({ onCtrlZero }: KeyboardShortcutsProps) {
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.ctrlKey && event.key === '0') {
        event.preventDefault();
        onCtrlZero();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onCtrlZero]);

  return null;
}