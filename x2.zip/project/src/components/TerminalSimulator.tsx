import { useState } from 'react';
import { Terminal } from 'lucide-react';
import { CardDetails, TerminalSimulation } from '../types/card';
import { generateARQC, encryptCardData } from '../utils/crypto';

interface TerminalSimulatorProps {
  cardDetails: CardDetails;
  onSimulationComplete: (result: TerminalSimulation) => void;
}

export function TerminalSimulator({ cardDetails, onSimulationComplete }: TerminalSimulatorProps) {
  const [isProcessing, setIsProcessing] = useState(false);

  const simulateTransaction = async () => {
    setIsProcessing(true);
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const arqc = generateARQC(JSON.stringify(cardDetails));
    const encryptedData = encryptCardData(cardDetails);
    
    const simulation: TerminalSimulation = {
      status: 'approved',
      arqc,
      timestamp: new Date().toISOString()
    };
    
    onSimulationComplete(simulation);
    setIsProcessing(false);
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
      <div className="flex items-center gap-3 mb-4">
        <Terminal size={24} className="text-green-500" />
        <h3 className="text-xl font-semibold text-white">Simulador de Terminal</h3>
      </div>
      
      <div className="space-y-4">
        <div className="bg-gray-900 p-4 rounded font-mono text-sm text-green-400">
          <p>Card: {cardDetails.number.replace(/\d(?=\d{4})/g, '*')}</p>
          <p>Exp: {cardDetails.expiry}</p>
          <p>Holder: {cardDetails.cardholder}</p>
        </div>
        
        <button
          onClick={simulateTransaction}
          disabled={isProcessing}
          className={`w-full py-3 rounded-lg font-medium transition-colors ${
            isProcessing
              ? 'bg-gray-600 cursor-not-allowed'
              : 'bg-green-600 hover:bg-green-700'
          }`}
        >
          {isProcessing ? 'Processando...' : 'Iniciar Transação'}
        </button>
      </div>
    </div>
  );
}