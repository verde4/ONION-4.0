import { CreditCard } from 'lucide-react';
import { CardDetails } from '../types/card';

interface CardPreviewProps {
  card: CardDetails;
}

export function CardPreview({ card }: CardPreviewProps) {
  const maskedNumber = card.number.replace(/(\d{4})/g, '$1 ').trim();
  
  return (
    <div className="relative w-96 h-56 bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-8 text-white shadow-xl transform transition-transform hover:scale-105">
      <div className="absolute top-4 right-4">
        <CreditCard size={32} className="text-gray-400" />
      </div>
      
      <div className="flex flex-col h-full justify-between">
        <div className="space-y-4">
          <div className="w-12 h-8 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded" />
          
          <div className="pt-4">
            <p className="font-mono text-xl tracking-wider">
              {maskedNumber}
            </p>
          </div>
        </div>
        
        <div className="flex justify-between items-end">
          <div>
            <p className="text-xs text-gray-400">Titular</p>
            <p className="font-mono tracking-wider">{card.cardholder}</p>
          </div>
          
          <div>
            <p className="text-xs text-gray-400">Validade</p>
            <p className="font-mono">{card.expiry}</p>
          </div>
        </div>
      </div>
    </div>
  );
}